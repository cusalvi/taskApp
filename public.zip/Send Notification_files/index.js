function validateForm() {
	var x = document.forms["send_notification"]["service_name"].value;
	if (x == null || x == "") {
		alert("Service Name must be filled out");
		return false;
	}
}

window.checked = function(elem){
	$('input:checked', $(elem).parent().parent()).prop('checked', false)
	$(elem).prop('checked', true)
}

var impactTypes = [
	"operational",
	"degraded_performance",
	"partial_outage",
	"major_outage"
]

function calDuration(){
	var startDate = document.getElementById("datetimepicker1").value;
	var endDate = document.getElementById("datetimepicker2").value;

	if(startDate && endDate){
		var endTimestamp = new Date(endDate).getTime();
		var startTimestamp = new Date(startDate).getTime();
		if(endTimestamp > startTimestamp){
			var timeDiff = Math.abs(new Date(endDate).getTime() - new Date(startDate).getTime()) / 1000;
			var timeObj = secondsToTime(timeDiff);
			if(timeObj && timeObj.h && timeObj.h > 0 && timeObj.m > 0 && timeObj.s > 0){
				$('#diffDuration').val(timeObj.h + " Hours " + timeObj.m + " Minutes " + timeObj.s + " Seconds");
			} else if(timeObj && timeObj.h && timeObj.m && timeObj.h > 0 && timeObj.m > 0){
				$('#diffDuration').val(timeObj.h + " Hours " + timeObj.m + " Minutes ");
			} else if(timeObj && timeObj.h && timeObj.h > 0){
				$('#diffDuration').val(timeObj.h + " Hours ");
			} else if(timeObj && timeObj.m && timeObj.m > 0){
				$('#diffDuration').val(timeObj.m + " Minutes");
			} else if(timeObj && timeObj.s && timeObj.s > 0){
				$('#diffDuration').val(timeObj.s + " Seconds");
			} else{
				$('#diffDuration').val("0 Minutes");
			}
		} else {
			alert("Please enter valid End Time")
		}
	} else{
		alert("Please enter Start Time and End Time");
	}
}

function secondsToTime(secs)
{
	var hours = Math.floor(secs / (60 * 60));
	
	var divisor_for_minutes = secs % (60 * 60);
	var minutes = Math.floor(divisor_for_minutes / 60);

	var divisor_for_seconds = divisor_for_minutes % 60;
	var seconds = Math.ceil(divisor_for_seconds);
	
	var obj = {
		"h": hours,
		"m": minutes,
		"s": seconds
	};
	return obj;
}
$(document).ready(function(){
	$('label').css('font-weight', 'bold')
	var evttypelist=document.send_notification.event_type;
	var evtstatelist=document.send_notification.event_state;
	var event_state = window.event_state =[
	"",
	["", "Planned|Planned", "In Progress|In Progress", "Extended|Extended", "Completed|Completed"],
	["", "Investigating|Investigating", "Identified|Identified", "Monitoring|Monitoring", "Resolved|Resolved"]
	]

	srvlist=document.send_notification.service;
	componentlist=document.send_notification.component_status;
	table = document.getElementById("status_table")
	sub_component = [""]
	// sub_component=[
	// "",
	// ["", "API's|api", "Management Portal|managementportal", "Database|database"],
	// "",
	// "",
	// "",
	// ["", "API's|api", "User Portal|userportal"]
	// ]
	$.getJSON('/Send%20Notification_files/sub-components.json', function(data, success, jqXHR){
		for(var key in data){
			var markup = "<option value='" + key + "'>" + data[key].label + "</option>"
			$('#service-list').append(markup)

			sub_component.push(data[key].subcomps)

		}
	})	
})

function updatecomponent(elem) {
	$('#table-wrapper').attr('style', 'display:block;')
// componentlist.options.length=0
selectedsrv = elem.selectedIndex
selectedtxt = $('option:selected', $(elem)).val()
if (selectedsrv>0){
	$('.table-data').remove()
	var arr = sub_component[selectedsrv]
	var length = arr.length
	for (i=0; i<length; i++){
		var split = arr[i].split("|")
		var label = 1
		if (split.length > 1){
			var str
			if(label == 1){
				str = split[0]
				label ++
			}
			var row = table.insertRow($('#status_table tr').length)
			row.setAttribute('class', 'table-data')
			var cell0 = row.insertCell(0)
			var cell1 = row.insertCell(1)
			var cell2 = row.insertCell(2)
			var cell3 = row.insertCell(3)
			var cell4 = row.insertCell(4)
			cell0.innerHTML = str
			cell0.setAttribute('style', 'background-color: #dfdfdf;')
			cell2.innerHTML = "<input onchange='window.checked(this)' type='checkbox' class='checkbox' data-index='" + i + "' name='"+ selectedtxt + "_" + split[1] + "'>"
			cell3.innerHTML = "<input onchange='window.checked(this)' type='checkbox' class='checkbox' data-index='" + i + "' name='"+ selectedtxt + "_" + split[1] + "'>"
			cell4.innerHTML = "<input onchange='window.checked(this)' type='checkbox' class='checkbox' data-index='" + i + "' name='"+ selectedtxt + "_" + split[1] + "'>"
			cell1.innerHTML = "<input onchange='window.checked(this)' type='checkbox' class='checkbox' data-index='" + i + "' name='"+ selectedtxt + "_" + split[1] + "'>"
		}
	}
}
}

function updatestate(selectedeventtype) {
	evtstatelist.options.length=0
	if (selectedeventtype>0){
		for (i=0; i<event_state[selectedeventtype].length; i++)
			evtstatelist.options[evtstatelist.options.length]=new Option(event_state[selectedeventtype][i].split("|")[0], event_state[selectedeventtype][i].split("|")[1])
	}
}