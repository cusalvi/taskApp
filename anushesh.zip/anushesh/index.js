function validateForm() {
    var x = document.forms["send_notification"]["service_name"].value;
    if (x == null || x == "") {
        alert("Service Name must be filled out");
        return false;
    }
}

function calDuration(){
	var startDate = document.getElementById("datetimepicker1").value;
	var endDate = document.getElementById("datetimepicker2").value;

	if(startDate && endDate){
		var endTimestamp = new Date(endDate).getTime();
		var startTimestamp = new Date(startDate).getTime();
		if(endTimestamp > startTimestamp){
			var timeDiff = Math.abs(new Date(endDate).getTime() - new Date(startDate).getTime()) / 1000;
			var timeObj = secondsToTime(timeDiff);
			if(timeObj && timeObj.h && timeObj.h > 0 && timeObj.m > 0 && timeObj.s > 0){
				$('#diffDuration').val(timeObj.h + " Hours " + timeObj.m + " Minutes " + timeObj.s + " Seconds");
			} else if(timeObj && timeObj.h && timeObj.m && timeObj.h > 0 && timeObj.m > 0){
				$('#diffDuration').val(timeObj.h + " Hours " + timeObj.m + " Minutes ");
			} else if(timeObj && timeObj.h && timeObj.h > 0){
				$('#diffDuration').val(timeObj.h + " Hours ");
			} else if(timeObj && timeObj.m && timeObj.m > 0){
				$('#diffDuration').val(timeObj.m + " Minutes");
			} else if(timeObj && timeObj.s && timeObj.s > 0){
				$('#diffDuration').val(timeObj.s + " Seconds");
			} else{
				$('#diffDuration').val("0 Minutes");
			}
		} else {
			alert("Please enter valid End Time")
		}
	} else{
		alert("Please enter Start Time and End Time");
	}
}

function secondsToTime(secs)
{
	var hours = Math.floor(secs / (60 * 60));
	
	var divisor_for_minutes = secs % (60 * 60);
	var minutes = Math.floor(divisor_for_minutes / 60);

	var divisor_for_seconds = divisor_for_minutes % 60;
	var seconds = Math.ceil(divisor_for_seconds);
	
	var obj = {
		"h": hours,
		"m": minutes,
		"s": seconds
	};
	return obj;
}